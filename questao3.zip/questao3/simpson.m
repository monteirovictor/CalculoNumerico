function [raiz] = simpson()

n = 5;
xn = 2;
xo = 0;
 
   if (n == 0)  
      printf('Divis�o por Zero\n');
   elseif (n<0)
       printf('Intervalo invalido\n');
   else
       if (mod(n,2)~=0)
       n = n+1;
       h=(xn-xo)/n;
       x=xo+h;
       somapares =0;
       somaimpares =0;

     for i=1:n-1
         
         if(mod(i,2) ==0)
         somapares = somapares + funcaoPolinomial(x);
         else
             somaimpares=somaimpares+funcaoPolinomial(x);   
           
         end
           x = x+h;
     end
       end
   end
   raiz = (h/3)*((funcaoPolinomial(xo)+funcaoPolinomial(xn)+4*somaimpares+2*somapares));  
end
   
    
   
     
       