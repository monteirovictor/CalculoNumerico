function [ f ] = funcaopolinomio(x)
    f = x*log(x)-3.2;


end

