function [raiz] = trapezio()

n = 5;
xn = 2;
xo = 0;
 
   if (n == 0)  
      printf('Divis�o por Zero\n');
   elseif (n<0)
       printf('Intervalo invalido\n');
   else
       h= (xn-xo)/n;
       x=xo+h;
       soma =0;
     for i=1:n-1
         soma = soma + funcaoPolinomial(x);
         x = x+h;
     end
   end
   raiz = h*((funcaoPolinomial(xo)+funcaoPolinomial(xn)/2 + soma));  
end
   
    
   
     
       