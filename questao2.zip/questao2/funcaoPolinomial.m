function [ f ] = funcaoPolinomial( x )
f = x^2;

end
