function [ f ] = funcaopolinomio(a,b,c,d,e,x)

f = a*x^4+b*x^3+c*x^2+d*x+e;

end

