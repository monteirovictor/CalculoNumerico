function [ f ] = funcaoPolinomial( a,b,c,d )
f = ((a+b+c)/d);

end

