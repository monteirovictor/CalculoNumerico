function [ valorDerivada2] = derivada2(x)
 
valorDerivada2 = 2;



end

