function [ valorFuncao ] = funcao( x )
 
valorFuncao = x^2-9.5*x + 8.5;



end

