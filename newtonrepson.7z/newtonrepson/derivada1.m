function [ valorDerivada1] = derivada1( x )
 
valorDerivada1 = 2*x-9.5;



end

