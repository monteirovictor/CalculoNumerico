function [raiz] = retangulo()

n = 5;
xn = 2;
xo = 0;
 
   if (n == 0)  
      printf('Divis�o por Zero\n');
   elseif (n<0)
       printf('Intervalo invalido\n');
   else
       h= (xn+xo)/n;
       xi=xo;
       xf = xi+h;
soma =0;
    teste=0;
     for i=1:n
         teste =   funcaoPolinomial((xi+xf)/2);
         soma=soma+teste;
        xi=xf;
        xf=xf+h;
         
     end
   end
   raiz = h*soma;  
end
   
    
   
     
       